__version__ = '0.29.0'
git_version = 'fc73f5a8567734ffa4c988b24d5432f0d3005974'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
